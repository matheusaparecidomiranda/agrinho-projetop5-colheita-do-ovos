let galinha;
let ovos = [];
let pontuacao = 0;

function setup() {
  createCanvas(400, 400);
  galinha = new Galinha();
}

function draw() {
  background("blue");
  
  // Mostrar a galinha
  galinha.mostrar();
  galinha.mover();
  
  // Criar ovos aleatoriamente
  if (frameCount % 60 === 0) {
    ovos.push(new Ovo());
  }
  
  // Mostrar e verificar ovos
  for (let i = ovos.length - 1; i >= 0; i--) {
    ovos[i].mostrar();
    ovos[i].mover();
    
    if (ovos[i].y > height) {
      // Ovo caiu no chão, remover
      ovos.splice(i, 1);
    } else if (ovos[i].colidiu(galinha)) {
      // Ovo pego pela galinha
      pontuacao++;
      ovos.splice(i, 1);
    }
  }
  
  // Mostrar pontuação
  fill(0);
  textSize(16);
  text('Pontuação: ' + pontuacao, 10, 20);
}

// Classe da galinha
class Galinha {
  constructor() {
    this.x = width / 2;
    this.y = height - 30;
    this.largura = 50;
    this.altura = 30;
  }
  
  mostrar() {
    fill(255, 200, 0);
    rect(this.x, this.y, this.largura, this.altura);
  }
  
  mover() {
    if (keyIsDown(LEFT_ARROW) && this.x > 0) {
      this.x -= 5;
    }
    if (keyIsDown(RIGHT_ARROW) && this.x < width - this.largura) {
      this.x += 5;
    }
  }
}

// Classe do ovo
class Ovo {
  constructor() {
    this.x = random(20, width - 20);
    this.y = 0;
    this.tamanho = 20;
    this.velocidade = 3;
  }
  
  mostrar() {
    fill(255);
    ellipse(this.x, this.y, this.tamanho);
  }
  
  mover() {
    this.y += this.velocidade;
  }
  
  colidiu(galinha) {
    // Verifica se o ovo colidiu com a galinha
    return (
      this.y + this.tamanho / 2 >= galinha.y &&
      this.x > galinha.x &&
      this.x < galinha.x + galinha.largura
    );
  }
}

